<?php

$conexion = mysql_connect("localhost","root","");
mysql_select_db("GRUPO-19-002", $conexion);


$usuario = $_POST['usuario'];
$contra = $_POST['contra'];
$mail = $_POST['mail'];
 
mysql_query("INSERT_INTO empleados (usuario,contra,mail) VALUES ('$usuario','$contra','mail')",$conexion);

?>
